import requests
from bs4 import BeautifulSoup
import re
import dns.resolver
from urllib.parse import urlparse
from datetime import datetime

print("\n=========== Website Security Analyzer ===========\n")

url = input("Enter Website URL: ")

security_headers = [
    "Content-Security-Policy",
    "Strict-Transport-Security",
    "X-Content-Type-Options",
    "X-Frame-Options",
    "X-XSS-Protection",
    "Referrer-Policy",
    "Permissions-Policy"
]

http_headers_to_check = [
    "Server",
    "X-Powered-By",
    "Content-Type",
    "Cache-Control",
    "Access-Control-Allow-Origin",
    "Set-Cookie"
]

subdomain_list = [
    "www","mail","ftp","admin","test","dev","portal","api","blog"
]

# REQUEST WEBSITE

try:
    response = requests.get(url, timeout=10)
except:
    print("Cannot access website")
    exit()

html = response.text
soup = BeautifulSoup(html,"html.parser")

parsed = urlparse(url)
domain = parsed.netloc.replace("www.","")

# EMAIL EXTRACTION

emails = set(re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", html))

# PHONE NUMBERS

phones = set(re.findall(r"\+?\d[\d -]{8,12}\d", html))


# METADATA

title = soup.title.string if soup.title else "No Title"

desc = soup.find("meta",attrs={"name":"description"})
description = desc["content"] if desc else "Not Found"

# SECURITY HEADERS CHECK

missing_security_headers = []
present_security_headers = []

for header in security_headers:
    if header in response.headers:
        present_security_headers.append(f"{header}: {response.headers[header]}")
    else:
        missing_security_headers.append(header)

# HTTP HEADERS ANALYSIS

http_headers_analysis = []
leaked_info = []

for header in http_headers_to_check:
    if header in response.headers:
        value = response.headers[header]
        http_headers_analysis.append(f"{header}: {value}")

        if header == "Server" and len(value) > 5:
            leaked_info.append(f"Server version exposed: {value}")

        if header == "X-Powered-By":
            leaked_info.append(f"Tech stack exposed: {value}")

        if header == "Access-Control-Allow-Origin" and "*" in value:
            leaked_info.append("CORS wildcard (*) detected")

# TECHNOLOGY DETECTION

technologies = []

if "wp-content" in html:
    technologies.append("WordPress")

if "react" in html.lower():
    technologies.append("ReactJS")

if "php" in html.lower():
    technologies.append("PHP")

server_header = response.headers.get("Server","").lower()

if "apache" in server_header:
    technologies.append("Apache")

if "nginx" in server_header:
    technologies.append("Nginx")

# SUBDOMAIN SCAN


found_subdomains = []

for sub in subdomain_list:
    subdomain = f"{sub}.{domain}"

    try:
        dns.resolver.resolve(subdomain,"A")
        found_subdomains.append(subdomain)
    except:
        pass

# DIRECTORY BRUTE FORCE

found_directories = []

try:
    with open("wordlist.txt") as f:
        directories = f.read().splitlines()

    for d in directories[:50]:

        target = f"{url.rstrip('/')}/{d}"

        try:
            r = requests.get(target, timeout=3)

            if r.status_code == 200:
                found_directories.append(target)

        except:
            pass

except:
    print("wordlist.txt not found - skipping directory scan")

# FIXED HTML SECTION


leak_section = ""

if leaked_info:

    leak_section = f"""
    <h3>🚨 Potential Information Leaks:</h3>
    <ul>
    {''.join([f'<li class="leak">{l}</li>' for l in leaked_info])}
    </ul>
    """

else:

    leak_section = "<p>No leaks detected ✅</p>"

# HTML REPORT

report = f"""
<html>
<head>
<title>Website Security Report</title>
<style>

body {{
font-family: Arial;
background:#0f172a;
color:white;
padding:30px;
}}

.card {{
background:#1e293b;
padding:20px;
margin:15px;
border-radius:10px;
}}

h1 {{color:#38bdf8}}

.leak {{color:red;font-weight:bold}}

</style>
</head>

<body>

<h1>Website Security Analyzer Report</h1>

<div class="card">
<h2>Target</h2>
<p>{url}</p>
<p>{datetime.now()}</p>
</div>

<div class="card">
<h2>Metadata</h2>
<p>Title: {title}</p>
<p>Description: {description}</p>
</div>

<div class="card">
<h2>Security Headers</h2>
<p>Missing: {missing_security_headers}</p>
</div>

<div class="card">
<h2>HTTP Headers</h2>
<ul>
{''.join([f'<li>{h}</li>' for h in http_headers_analysis])}
</ul>
{leak_section}
</div>

<div class="card">
<h2>Emails ({len(emails)})</h2>
<ul>{''.join([f'<li>{e}</li>' for e in emails])}</ul>
</div>

<div class="card">
<h2>Contacts ({len(phones)})</h2>
<ul>{''.join([f'<li>{p}</li>' for p in phones])}</ul>
</div>

<div class="card">
<h2>Technologies</h2>
<ul>{''.join([f'<li>{t}</li>' for t in technologies])}</ul>
</div>

<div class="card">
<h2>Subdomains</h2>
<ul>{''.join([f'<li>{s}</li>' for s in found_subdomains])}</ul>
</div>

<div class="card">
<h2>Directories</h2>
<ul>{''.join([f'<li>{d}</li>' for d in found_directories])}</ul>
</div>

<div class="card">
<h2>Directories</h2>
<ul>{''.join([f'<li>{d}</li>' for d in found_directories])}</ul>
</div>

<div class="footer">
© Copyright Poojan Patel ,Dilip Prajapati. All Rights Reserved, 2026
</div>

</body>
</html>
"""

filename = f"security_report_{domain}.html"

with open(filename,"w",encoding="utf-8") as f:
    f.write(report)

print("\nSCAN COMPLETED")
print("Emails:",len(emails))
print("Contacts:",len(phones))
print("Subdomains:",len(found_subdomains))
print("Directories:",len(found_directories))
print("Report saved:",filename)